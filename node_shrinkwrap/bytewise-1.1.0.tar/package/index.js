// TODO: initialize and export a standard bytewise encoding, add hex and binary
module.exports = require('./encoding/')
