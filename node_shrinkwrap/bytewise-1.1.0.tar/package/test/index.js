require('../')

// require('typewise/test/')
require('bytewise-core/test/')

// TODO: binary, hex tests, refactor core tests to allow encoder to be provided
