// TODO: standard bytewise encoding constructor
// TODO: enhance binary encoding with optional hex helpers
module.exports = require('./binary')