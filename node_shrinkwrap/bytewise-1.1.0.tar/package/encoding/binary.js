// require typewise first to extend with core typewise functionality
require('typewise')

// TODO: bytewise-binary encoding -- no hex parsing or toString hackery
module.exports = require('bytewise-core')
