var bytewise = require('bytewise')

module.exports = {
  encode: bytewise.encode,
  decode: bytewise.decode,
  lowerBound: null,
  upperBound: undefined,
  buffer: true
}
