var typewise = require('../')
var tape = require('tape')

//
// run typewise-core tests first
//
require('typewise-core/test/')

// TODO: test extended types and comparators
