//
// extend core typewise
//
require('./collation')

module.exports = require('typewise-core/base')
