//
// extend core typewise collations
//
var collation = require('typewise-core/collation')

// TODO: set, map

module.exports = collation
