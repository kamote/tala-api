module.exports = require('./lib/context-traversal');
