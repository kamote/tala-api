console.log(typeof global.gc);
