var print = module.exports = function print(msg) {
  console.log(msg);
}
print.usage = 'Print out a <msg>';

