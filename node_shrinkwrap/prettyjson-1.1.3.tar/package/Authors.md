Go to the [https://github.com/rafeca/prettyjson/graphs/contributors](GitHub contributors graph page)
to see the list of contributors.
