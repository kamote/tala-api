Go to [GitHub releases page](https://github.com/rafeca/prettyjson/releases) to
see the history of releases.
