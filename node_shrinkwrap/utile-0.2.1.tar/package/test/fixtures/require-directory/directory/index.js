exports.me = 'directory/index.js';

