__[DEPRECATED] this module is reorganized into [power-assert-runtime](https://github.com/twada/power-assert-runtime)__


### [0.1.1](https://github.com/twada/power-assert-renderers/releases/tag/v0.1.1) (2016-06-05)


#### Bug Fixes

  * stay compatible with power-assert-formatter ([6b912f05](https://github.com/twada/power-assert-renderers/commit/6b912f050c917fbfb139f578de094c16746be11b))


## [0.1.0](https://github.com/twada/power-assert-renderers/releases/tag/v0.1.0) (2015-10-21)


#### Features

  * extract built-in renderers out from [power-assert-formatter](https://github.com/power-assert-js/power-assert-formatter)
  * implement `SuccinctRenderer`
