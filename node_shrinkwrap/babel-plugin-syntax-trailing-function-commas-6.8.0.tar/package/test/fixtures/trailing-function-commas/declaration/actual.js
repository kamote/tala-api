function thisIsAFunctionWithAVeryLongNameAndWayTooManyParameters(
  thisIsTheFirstParameter, andThisOneIsRelatedToIt,
  butNotThisOne,
  andNeitherThis,
  inFactThereArentThatManyParameters,
) {
  throw null;
}
