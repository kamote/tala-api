## [1.0.0](https://github.com/twada/call-matcher/releases/tag/v1.0.0) (2016-05-28)


#### Features

  * consolidate ponyfills into core-js ([a083946c](https://github.com/twada/call-matcher/commit/a083946c26cfd236122b5298c3ea5c1facb0baca))


## [0.1.0](https://github.com/twada/call-matcher/releases/tag/v0.1.0) (2015-12-23)


#### Features

  * initial release (extract call-matcher from escallmatch)
