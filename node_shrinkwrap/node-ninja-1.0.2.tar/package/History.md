0.2.0 / 2016/02/15
==================

 * Forked from node-gyp and fixed to workaround Gyp dependency path bug.

