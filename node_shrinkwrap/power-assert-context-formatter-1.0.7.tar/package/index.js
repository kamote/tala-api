module.exports = require('./lib/create-formatter');
