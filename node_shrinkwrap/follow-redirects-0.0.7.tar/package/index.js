module.exports = require('./create')({
  'http': require('http'),
  'https': require('https')
});
