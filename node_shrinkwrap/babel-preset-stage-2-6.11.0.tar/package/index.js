module.exports = {
  presets: [
    require("babel-preset-stage-3")
  ],
  plugins: [
    require("babel-plugin-transform-object-rest-spread")
  ]
};
