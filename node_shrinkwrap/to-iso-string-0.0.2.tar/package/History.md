
0.0.2 - May 12, 2015
--------------------

- Fix npm publish issue

0.0.1 - October 16, 2013
------------------------
:sparkles:
