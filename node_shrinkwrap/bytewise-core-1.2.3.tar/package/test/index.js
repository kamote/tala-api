var tape = require('tape')

require('./basic')
require('./buffers')
require('./order')
require('./serialization')
require('./ranges')
require('./strings')
