typewise-core
=============

A stripped down [typewise](https://github.com/deanlandolt/typewise) profile containing the most common types used for encoding complex keyspaces in [bytewise](https://github.com/deanlandolt/bytewise). This is the profile used by the [bytewise-core](https://github.com/deanlandolt/bytewise-core) encoding.


## License

[MIT](http://deanlandolt.mit-license.org/)
